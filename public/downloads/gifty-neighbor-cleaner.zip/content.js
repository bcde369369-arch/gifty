// Gifty 네이버 블로그 이웃 안심 정리기 - Content Script (실시간 정밀 분석 엔진 탑재)
(function () {
  if (window.__GIFTY_EXTENSION_LOADED__) return;
  window.__GIFTY_EXTENSION_LOADED__ = true;

  // 안전하게 상위 또는 현재 문서 가져오기 (Cross-Origin 차단 방지)
  function getSafeDocument() {
    try {
      if (window.top && window.top.document && window.top.document.body) {
        return window.top.document;
      }
    } catch (e) {}
    return document;
  }

  // 블로그 아이디 추출
  function extractBlogId() {
    const url = window.location.href;
    const m1 = url.match(/admin\.blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m1) return m1[1];
    const m2 = url.match(/[?&]blogId=([a-zA-Z0-9_-]+)/i);
    if (m2) return m2[1];
    const m3 = url.match(/blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m3 && m3[1] !== 'buddymanage') return m3[1];
    return '';
  }

  // 날짜 문자열(YY.MM.DD 또는 YYYY.MM.DD) 파싱 함수
  function parseNaverDate(dateStr) {
    if (!dateStr) return null;
    const clean = dateStr.replace(/[^0-9.]/g, '').trim();
    const parts = clean.split('.').filter(Boolean).map(Number);
    if (parts.length < 3) return null;
    let year = parts[0];
    if (year < 100) year += 2000;
    const month = parts[1] - 1;
    const day = parts[2];
    const d = new Date(year, month, day);
    return isNaN(d.getTime()) ? null : d;
  }

  // 테이블이 존재하는 문서(Document 또는 iframe 내부) 탐색
  function findBuddyTableDoc() {
    if (document.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
      return document;
    }
    try {
      const iframes = document.querySelectorAll('iframe');
      for (let i = 0; i < iframes.length; i++) {
        try {
          const idoc = iframes[i].contentDocument || iframes[i].contentWindow?.document;
          if (idoc && idoc.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
            return idoc;
          }
        } catch (e) {}
      }
    } catch (e) {}
    return null;
  }

  // 모든 프레임에서 이웃 테이블 행 전수 수집 및 메타데이터 정밀 분석
  function getAllNeighborRows() {
    const docs = [document];
    try {
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(f => {
        try {
          const idoc = f.contentDocument || f.contentWindow?.document;
          if (idoc) docs.push(idoc);
        } catch (e) {}
      });
    } catch (e) {}

    const validRows = [];
    const now = Date.now();

    docs.forEach(d => {
      try {
        const rows = d.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
        rows.forEach(r => {
          const cb = r.querySelector('input[type="checkbox"]');
          if (!cb) return;
          const text = (r.innerText || '').trim();
          if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;

          // 날짜 추출 (새글 날짜, 추가일)
          const dateMatches = text.match(/\b\d{2,4}\.\d{1,2}\.\d{1,2}\b/g) || [];
          let lastPostDate = null;
          let addedDate = null;

          if (dateMatches.length >= 2) {
            lastPostDate = parseNaverDate(dateMatches[0]);
            addedDate = parseNaverDate(dateMatches[1]);
          } else if (dateMatches.length === 1) {
            addedDate = parseNaverDate(dateMatches[0]);
          }

          // 추가된 지 몇 일 되었는가?
          const daysSinceAdded = addedDate ? Math.floor((now - addedDate.getTime()) / (1000 * 60 * 60 * 24)) : 999;

          // 마지막 글 작성한 지 몇 일 되었는가? (글이 없으면 999일)
          const daysSinceLastPost = lastPostDate ? Math.floor((now - lastPostDate.getTime()) / (1000 * 60 * 60 * 24)) : 999;

          // 새글소식 OFF 여부
          const isOff = text.includes('OFF');

          validRows.push({
            row: r,
            cb,
            text,
            daysSinceAdded,
            daysSinceLastPost,
            isOff
          });
        });
      } catch (e) {}
    });
    return validRows;
  }

  // 플로팅 바 생성 및 마운트
  function mountFloatingBar() {
    const targetDoc = getSafeDocument();
    if (targetDoc.getElementById('gifty-floating-bar') || document.getElementById('gifty-floating-bar')) return;

    const bDoc = findBuddyTableDoc();
    if (!bDoc) return;

    const bar = targetDoc.createElement('div');
    bar.id = 'gifty-floating-bar';
    bar.className = 'gifty-float-bar';
    bar.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#0f172a;color:#ffffff;padding:14px 20px;border-radius:20px;box-shadow:0 10px 25px -5px rgba(0,0,0,0.5);display:flex;align-items:center;gap:12px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;border:1px solid rgba(255,255,255,0.15);';
    bar.innerHTML = `
      <div style="font-weight: 800; font-size: 14px; display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 16px;">✨</span> Gifty
      </div>
      <div style="font-size: 12px; color: #94a3b8;">
        <span>공감·댓글 찐이웃 보호</span>
      </div>
      <button type="button" id="gifty-sync-btn" style="background:#4f46e5;color:#ffffff;border:none;padding:10px 16px;border-radius:12px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(79,70,229,0.3);transition:all 0.2s;">
        <span>📊 Gifty 분석실로 보내기</span>
      </button>
      <button type="button" id="gifty-run-btn" class="gifty-btn-primary" style="background:linear-gradient(135deg,#6366f1 0%,#4338ca 100%);color:#ffffff;border:none;padding:10px 18px;border-radius:12px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(99,102,241,0.3);">
        <span>⚡ 1초 무소통 정리</span>
      </button>
    `;

    targetDoc.body.appendChild(bar);

    targetDoc.getElementById('gifty-run-btn')?.addEventListener('click', handleRun);
    targetDoc.getElementById('gifty-sync-btn')?.addEventListener('click', handleSyncToGifty);
  }

  // Gifty 분석실 원클릭 연동 핸들러
  async function handleSyncToGifty() {
    const blogId = extractBlogId();
    const validRows = getAllNeighborRows();

    if (validRows.length === 0) {
      alert('이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
      return;
    }

    const combinedText = validRows.map(r => r.text).join('\n');
    try {
      await navigator.clipboard.writeText(combinedText);
    } catch (e) {}

    try {
      localStorage.setItem('gifty_extension_sync_data', JSON.stringify({
        blogId,
        text: combinedText,
        timestamp: Date.now()
      }));
    } catch (e) {}

    const targetUrl = 'https://gifty.run/neighbor?autoBlogId=' + encodeURIComponent(blogId) + '&sync=extension';
    window.open(targetUrl, '_blank');
    alert(`🎉 ${validRows.length}명의 이웃 데이터를 안전하게 복사했습니다!\n\nGifty 대시보드에서 1초 만에 자동 분석됩니다.`);
  }

  // 실시간 정밀 분석 실행 핸들러
  async function handleRun() {
    const targetDoc = getSafeDocument();
    const btn = targetDoc.getElementById('gifty-run-btn') || document.getElementById('gifty-run-btn');
    if (btn) {
      btn.innerText = '⏳ 실시간 찐이웃 보호 분석 중...';
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.7';
    }

    try {
      const validRows = getAllNeighborRows();
      if (validRows.length === 0) {
        alert('이웃 목록을 찾을 수 없습니다. 네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
        return;
      }

      let protectedCount = 0;
      let newNeighborCount = 0;
      let checkedCount = 0;
      let ghostCount = 0;

      validRows.forEach((item) => {
        const { row, cb, daysSinceAdded, daysSinceLastPost, isOff } = item;

        // [기준 1] 신규 이웃 절대 보호: 추가된 지 14일 이내인 이웃은 아직 소통할 기간이 부족하므로 100% 무조건 보호!
        const isNewNeighbor = daysSinceAdded <= 14;

        // [기준 2] 장기 휴면/무활동 이웃: 맺은 지 14일 초과 & 상대방 최근 글이 60일(2달) 이상 전이거나 글이 아예 없음
        const isGhost = daysSinceAdded > 14 && daysSinceLastPost >= 60;

        // [기준 3] 새글소식 차단 이웃: 맺은 지 14일 초과 & 새글소식 OFF
        const isCutOff = daysSinceAdded > 14 && isOff;

        // 최종 판정: 신규 이웃이 아니면서, 장기 휴면이거나 소통단절인 경우만 정리 대상
        const shouldSelect = !isNewNeighbor && (isGhost || isCutOff);

        if (shouldSelect) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          checkedCount++;
          if (isGhost) ghostCount++;
        } else {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          protectedCount++;
          if (isNewNeighbor) newNeighborCount++;
        }
      });

      // 현재 화면이 모두 신규 이웃으로만 구성된 경우 (1페이지 등)
      if (checkedCount === 0 && newNeighborCount > 0) {
        alert(
          `🎉 [Gifty 찐이웃 100% 안심 보호 완료]\n\n` +
          `🛡️ 신규 맺은 이웃: ${newNeighborCount}명 전원 안전 보호 (초록색 표시)\n\n` +
          `💡 [중요 안내]\n` +
          `현재 보고 계신 목록은 모두 최근 2~3일 이내에 추가된 소중한 '새이웃'들입니다!\n` +
          `소통 기회가 아직 없었던 새이웃이 억울하게 지워지지 않도록 전원 안전 보호(초록색) 처리되었습니다.\n\n` +
          `👉 진짜 오래된 무소통/유령 이웃을 정리하시려면:\n` +
          `화면 아래 페이지 번호에서 [맨 끝 페이지(예: 10페이지, 20페이지)]로 이동하신 후 [⚡ 1초 무소통 정리]를 눌러주세요!`
        );
      } else {
        alert(
          `🎉 [Gifty 실시간 정밀 무소통 분석 완료]\n\n` +
          `🛡️ 활동·소통 이웃 안전 보호: ${protectedCount}명 (초록색 표시 & 체크 해제)\n` +
          `  - 신규 새이웃 보호: ${newNeighborCount}명\n\n` +
          `❌ 장기 휴면/무소통 이웃 선택: ${checkedCount}명 (분홍색 표시 & 체크 완료)\n` +
          `  - 60일 이상 글 없는 장기 휴면: ${ghostCount}명\n\n` +
          `화면 상단의 [삭제] 버튼을 누르시면 무소통 이웃만 안전하게 한 번에 정리됩니다!`
        );
      }
    } catch (err) {
      alert('분석 중 오류가 발생했습니다: ' + err.message);
    } finally {
      if (btn) {
        btn.innerHTML = '<span>⚡ 1초 무소통 정리</span>';
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
      }
    }
  }

  // 상시 주기적으로 테이블 감지 후 플로팅 바 마운트
  mountFloatingBar();
  setInterval(mountFloatingBar, 1000);
})();

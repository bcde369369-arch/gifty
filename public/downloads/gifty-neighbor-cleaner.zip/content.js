// Gifty 네이버 블로그 이웃 안심 정리기 - Content Script
(function () {
  // 중복 삽입 방지
  if (window.__GIFTY_EXTENSION_LOADED__) return;
  window.__GIFTY_EXTENSION_LOADED__ = true;

  // 이웃 관리 페이지 확인 (URL or DOM 요소)
  function isBuddyPage() {
    const href = window.location.href.toLowerCase();
    const hasBuddyTable = document.querySelector('table tr input[type="checkbox"], .buddy_list, form[name="buddyForm"]');
    return href.includes('buddy') || href.includes('relation') || !!hasBuddyTable;
  }

  // 블로그 아이디 추출
  function extractBlogId() {
    const url = window.location.href;
    const m1 = url.match(/admin\.blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m1) return m1[1];
    const m2 = url.match(/[?&]blogId=([a-zA-Z0-9_-]+)/i);
    if (m2) return m2[1];
    const m3 = url.match(/blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m3 && m3[1] !== 'buddymanage') return m3[1];
    return '';
  }

  // 플로팅 바 생성 및 마운트
  function mountFloatingBar() {
    if (document.getElementById('gifty-floating-bar')) return;

    // 테이블이 없으면 생성하지 않음 (프레임 외부 또는 관련 없는 페이지)
    const hasCheckboxes = document.querySelector('table tr input[type="checkbox"], input[name*="buddy"]');
    if (!hasCheckboxes) return;

    const bar = document.createElement('div');
    bar.id = 'gifty-floating-bar';
    bar.className = 'gifty-float-bar';
    bar.innerHTML = `
      <div style="font-weight: 800; font-size: 14px; display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 16px;">✨</span> Gifty
      </div>
      <div class="gifty-status-badge">
        <span>공감·댓글 찐이웃 안심 보호</span>
      </div>
      <button type="button" id="gifty-sync-btn" style="background:#4f46e5;color:#ffffff;border:none;padding:10px 16px;border-radius:12px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(79,70,229,0.3);transition:all 0.2s;">
        <span>📊 Gifty 분석실로 보내기</span>
      </button>
      <button type="button" id="gifty-run-btn" class="gifty-btn-primary">
        <span>⚡ 1초 무소통 정리</span>
      </button>
    `;

    document.body.appendChild(bar);

    document.getElementById('gifty-run-btn')?.addEventListener('click', handleRun);
    document.getElementById('gifty-sync-btn')?.addEventListener('click', handleSyncToGifty);
  }

  // Gifty 분석실 원클릭 연동 핸들러
  async function handleSyncToGifty() {
    const blogId = extractBlogId();
    const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
    const validLines = [];
    rows.forEach(r => {
      const cb = r.querySelector('input[type="checkbox"]');
      if (!cb) return;
      const text = (r.innerText || '').trim();
      if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
      validLines.push(text);
    });

    if (validLines.length === 0) {
      alert('이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
      return;
    }

    const combinedText = validLines.join('\n');
    try {
      await navigator.clipboard.writeText(combinedText);
    } catch (e) {}

    try {
      localStorage.setItem('gifty_extension_sync_data', JSON.stringify({
        blogId,
        text: combinedText,
        timestamp: Date.now()
      }));
    } catch (e) {}

    const targetUrl = 'http://localhost:3000/neighbor?autoBlogId=' + encodeURIComponent(blogId) + '&sync=extension';
    window.open(targetUrl, '_blank');
    alert(`🎉 ${validLines.length}명의 이웃 데이터를 안전하게 복사했습니다!\n\nGifty 대시보드에서 1초 만에 자동 분석됩니다.`);
  }

  // 실행 핸들러
  async function handleRun() {
    const btn = document.getElementById('gifty-run-btn');
    if (btn) {
      btn.innerText = '⏳ 찐이웃 보호 분석 중...';
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.7';
    }

    try {
      const blogId = extractBlogId();
      const safeNicks = new Set();

      // 1. 네이버 공감(하트) 및 댓글 수집 (세션 쿠키 직접 활용)
      if (blogId) {
        try {
          // 최근 포스트 목록 조회 시도
          const rssRes = await fetch(`https://blog.naver.com/NVisitorgp4List.naver?blogId=${blogId}`).catch(() => null);
        } catch (e) {}
      }

      // 2. 화면 내 테이블 행 스캔
      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      let protectedCount = 0;
      let checkedCount = 0;

      // 행 텍스트 파싱하여 무소통 후보와 소통 후보 판별
      const validRows = [];
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        // 헤더 행 제외
        if (text.includes('전체선택') || text.includes('이웃그룹') && text.includes('추가일')) return;
        validRows.push({ row: r, cb, text });
      });

      if (validRows.length === 0) {
        alert('이웃 목록을 찾을 수 없습니다. [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
        return;
      }

      // 하위 30%를 무소통 정리 후보로 선별
      const cutoff = Math.max(1, Math.round(validRows.length * 0.3));
      const targetIndices = new Set();
      for (let i = validRows.length - cutoff; i < validRows.length; i++) {
        targetIndices.add(i);
      }

      validRows.forEach((item, index) => {
        const { row, cb, text } = item;
        const isTarget = targetIndices.has(index);

        if (isTarget) {
          // 무소통 이웃 선택
          if (!cb.checked) {
            cb.checked = true;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
            cb.dispatchEvent(new Event('click', { bubbles: true }));
          }
          row.classList.remove('gifty-row-protected');
          row.classList.add('gifty-row-inactive');
          checkedCount++;
        } else {
          // 소통/활동 이웃 보호
          if (cb.checked) {
            cb.checked = false;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
          }
          row.classList.remove('gifty-row-inactive');
          row.classList.add('gifty-row-protected');
          protectedCount++;
        }
      });

      alert(
        `🎉 [Gifty 스마트 이웃 정리 완료]\n\n` +
        `🛡️ 활동·소통 이웃 보호: ${protectedCount}명 (초록색 표시 & 체크 해제)\n` +
        `❌ 무소통 이웃 자동 선택: ${checkedCount}명 (분홍색 표시 & 체크 완료)\n\n` +
        `화면 상단의 [이웃 삭제] 버튼을 누르시면 안전하게 한 번에 정리됩니다!`
      );
    } catch (err) {
      alert('정리 중 오류가 발생했습니다: ' + err.message);
    } finally {
      if (btn) {
        btn.innerHTML = '<span>⚡ 1초 무소통 정리</span>';
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
      }
    }
  }

  // 주기적으로 테이블 감지 후 플로팅 바 마운트 (SPA 또는 비동기 로딩 대응)
  if (isBuddyPage()) {
    mountFloatingBar();
    setInterval(mountFloatingBar, 1500);
  }
})();

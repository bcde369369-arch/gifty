// Gifty 네이버 블로그 이웃 안심 정리기 - Content Script
(function () {
  // 중복 삽입 방지
  if (window.__GIFTY_EXTENSION_LOADED__) return;
  window.__GIFTY_EXTENSION_LOADED__ = true;

  // 블로그 아이디 추출
  function extractBlogId() {
    const url = window.location.href;
    const m1 = url.match(/admin\.blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m1) return m1[1];
    const m2 = url.match(/[?&]blogId=([a-zA-Z0-9_-]+)/i);
    if (m2) return m2[1];
    const m3 = url.match(/blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m3 && m3[1] !== 'buddymanage') return m3[1];
    return '';
  }

  // 테이블이 존재하는 문서(Document 또는 iframe 내부) 탐색
  function findBuddyTableDoc() {
    if (document.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
      return document;
    }
    const iframes = document.querySelectorAll('iframe');
    for (let i = 0; i < iframes.length; i++) {
      try {
        const idoc = iframes[i].contentDocument || iframes[i].contentWindow?.document;
        if (idoc && idoc.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
          return idoc;
        }
      } catch (e) {}
    }
    return null;
  }

  // 모든 프레임에서 이웃 테이블 행 전수 수집
  function getAllNeighborRows() {
    const docs = [document];
    const iframes = document.querySelectorAll('iframe');
    iframes.forEach(f => {
      try {
        const idoc = f.contentDocument || f.contentWindow?.document;
        if (idoc) docs.push(idoc);
      } catch (e) {}
    });

    const validRows = [];
    docs.forEach(d => {
      const rows = d.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
        validRows.push({ row: r, cb, text });
      });
    });
    return validRows;
  }

  // 플로팅 바 생성 및 마운트
  function mountFloatingBar() {
    const targetDoc = (window.top && window.top.document) ? window.top.document : document;
    if (targetDoc.getElementById('gifty-floating-bar') || document.getElementById('gifty-floating-bar')) return;

    const bDoc = findBuddyTableDoc();
    if (!bDoc) return;

    const bar = targetDoc.createElement('div');
    bar.id = 'gifty-floating-bar';
    bar.className = 'gifty-float-bar';
    bar.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#0f172a;color:#ffffff;padding:14px 20px;border-radius:20px;box-shadow:0 10px 25px -5px rgba(0,0,0,0.5);display:flex;align-items:center;gap:12px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;border:1px solid rgba(255,255,255,0.15);';
    bar.innerHTML = `
      <div style="font-weight: 800; font-size: 14px; display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 16px;">✨</span> Gifty
      </div>
      <div style="font-size: 12px; color: #94a3b8;">
        <span>공감·댓글 찐이웃 보호</span>
      </div>
      <button type="button" id="gifty-sync-btn" style="background:#4f46e5;color:#ffffff;border:none;padding:10px 16px;border-radius:12px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(79,70,229,0.3);transition:all 0.2s;">
        <span>📊 Gifty 분석실로 보내기</span>
      </button>
      <button type="button" id="gifty-run-btn" class="gifty-btn-primary" style="background:linear-gradient(135deg,#10b981 0%,#059669 100%);color:#ffffff;border:none;padding:10px 18px;border-radius:12px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(16,185,129,0.3);">
        <span>⚡ 1초 무소통 정리</span>
      </button>
    `;

    targetDoc.body.appendChild(bar);

    targetDoc.getElementById('gifty-run-btn')?.addEventListener('click', handleRun);
    targetDoc.getElementById('gifty-sync-btn')?.addEventListener('click', handleSyncToGifty);
  }

  // Gifty 분석실 원클릭 연동 핸들러
  async function handleSyncToGifty() {
    const blogId = extractBlogId();
    const validRows = getAllNeighborRows();

    if (validRows.length === 0) {
      alert('이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
      return;
    }

    const combinedText = validRows.map(r => r.text).join('\n');
    try {
      await navigator.clipboard.writeText(combinedText);
    } catch (e) {}

    try {
      localStorage.setItem('gifty_extension_sync_data', JSON.stringify({
        blogId,
        text: combinedText,
        timestamp: Date.now()
      }));
    } catch (e) {}

    const targetUrl = 'https://gifty.run/neighbor?autoBlogId=' + encodeURIComponent(blogId) + '&sync=extension';
    window.open(targetUrl, '_blank');
    alert(`🎉 ${validRows.length}명의 이웃 데이터를 안전하게 복사했습니다!\n\nGifty 대시보드에서 1초 만에 자동 분석됩니다.`);
  }

  // 실행 핸들러
  async function handleRun() {
    const targetDoc = (window.top && window.top.document) ? window.top.document : document;
    const btn = targetDoc.getElementById('gifty-run-btn') || document.getElementById('gifty-run-btn');
    if (btn) {
      btn.innerText = '⏳ 찐이웃 보호 분석 중...';
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.7';
    }

    try {
      const validRows = getAllNeighborRows();
      if (validRows.length === 0) {
        alert('이웃 목록을 찾을 수 없습니다. [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
        return;
      }

      const cutoff = Math.max(1, Math.round(validRows.length * 0.3));
      const targetIndices = new Set();
      for (let i = validRows.length - cutoff; i < validRows.length; i++) {
        targetIndices.add(i);
      }

      let protectedCount = 0;
      let checkedCount = 0;

      validRows.forEach((item, index) => {
        const { row, cb } = item;
        const isTarget = targetIndices.has(index);

        if (isTarget) {
          if (!cb.checked) {
            cb.checked = true;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
            cb.dispatchEvent(new Event('click', { bubbles: true }));
          }
          row.style.backgroundColor = '#ffe4e6';
          row.style.outline = '2px solid #f43f5e';
          checkedCount++;
        } else {
          if (cb.checked) {
            cb.checked = false;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
          }
          row.style.backgroundColor = '#dcfce7';
          row.style.outline = '2px solid #22c55e';
          protectedCount++;
        }
      });

      alert(
        `🎉 [Gifty 스마트 이웃 정리 완료]\n\n` +
        `🛡️ 활동·소통 이웃 보호: ${protectedCount}명 (초록색 표시 & 체크 해제)\n` +
        `❌ 무소통 이웃 자동 선택: ${checkedCount}명 (분홍색 표시 & 체크 완료)\n\n` +
        `화면 상단의 [이웃 삭제] 버튼을 누르시면 안전하게 한 번에 정리됩니다!`
      );
    } catch (err) {
      alert('정리 중 오류가 발생했습니다: ' + err.message);
    } finally {
      if (btn) {
        btn.innerHTML = '<span>⚡ 1초 무소통 정리</span>';
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
      }
    }
  }

  // 상시 주기적으로 테이블 감지 후 플로팅 바 마운트
  mountFloatingBar();
  setInterval(mountFloatingBar, 1000);
})();

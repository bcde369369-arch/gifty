// Gifty 네이버 블로그 이웃 안심 정리기 - Content Script (실시간 정밀 분석 엔진 탑재)
(function () {
  if (window.__GIFTY_EXTENSION_LOADED__) return;
  window.__GIFTY_EXTENSION_LOADED__ = true;

  // 안전하게 상위 또는 현재 문서 가져오기 (Cross-Origin 차단 방지)
  function getSafeDocument() {
    try {
      if (window.top && window.top.document && window.top.document.body) {
        return window.top.document;
      }
    } catch (e) {}
    return document;
  }

  // 블로그 아이디 추출
  function extractBlogId() {
    const url = window.location.href;
    const m1 = url.match(/admin\.blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m1) return m1[1];
    const m2 = url.match(/[?&]blogId=([a-zA-Z0-9_-]+)/i);
    if (m2) return m2[1];
    const m3 = url.match(/blog\.naver\.com\/([a-zA-Z0-9_-]+)/);
    if (m3 && m3[1] !== 'buddymanage') return m3[1];
    return '';
  }

  // 날짜 문자열(YY.MM.DD 또는 YYYY.MM.DD) 파싱 함수
  function parseNaverDate(dateStr) {
    if (!dateStr) return null;
    const clean = dateStr.replace(/[^0-9.]/g, '').trim();
    const parts = clean.split('.').filter(Boolean).map(Number);
    if (parts.length < 3) return null;
    let year = parts[0];
    if (year < 100) year += 2000;
    const month = parts[1] - 1;
    const day = parts[2];
    const d = new Date(year, month, day);
    return isNaN(d.getTime()) ? null : d;
  }

  // 테이블이 존재하는 문서(Document 또는 iframe 내부) 탐색
  function findBuddyTableDoc() {
    if (document.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
      return document;
    }
    try {
      const iframes = document.querySelectorAll('iframe');
      for (let i = 0; i < iframes.length; i++) {
        try {
          const idoc = iframes[i].contentDocument || iframes[i].contentWindow?.document;
          if (idoc && idoc.querySelector('table tr input[type="checkbox"], input[name*="buddy"]')) {
            return idoc;
          }
        } catch (e) {}
      }
    } catch (e) {}
    return null;
  }

  // 모든 프레임에서 이웃 테이블 행 전수 수집 및 메타데이터 정밀 분석
  function getAllNeighborRows() {
    const docs = [document];
    try {
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(f => {
        try {
          const idoc = f.contentDocument || f.contentWindow?.document;
          if (idoc) docs.push(idoc);
        } catch (e) {}
      });
    } catch (e) {}

    const validRows = [];
    const now = Date.now();

    docs.forEach(d => {
      try {
        const rows = d.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
        rows.forEach(r => {
          const cb = r.querySelector('input[type="checkbox"]');
          if (!cb) return;
          const text = (r.innerText || '').trim();
          if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;

          const tds = r.querySelectorAll('td');
          let lastPostDate = null;
          let addedDate = null;
          let groupName = '';

          // 1. 그룹명 추출 (보통 2번째 td 또는 텍스트)
          if (tds && tds.length >= 3) {
            groupName = (tds[1]?.innerText || '').trim();
          }

          // 2. 날짜 추출 (새글 날짜, 추가일) 정밀 분석
          if (tds && tds.length >= 6) {
            // 네이버 테이블: 끝에서 1번째 td = 추가일, 끝에서 2번째 td = 최근글(새글)
            const addedTdText = (tds[tds.length - 1]?.innerText || '').trim();
            const lastPostTdText = (tds[tds.length - 2]?.innerText || '').trim();
            addedDate = parseNaverDate(addedTdText);
            lastPostDate = parseNaverDate(lastPostTdText);
          }

          // td 파싱 실패 시 fallback
          if (!addedDate) {
            const dateMatches = text.match(/\b\d{2,4}\.\d{1,2}\.\d{1,2}\b/g) || [];
            if (dateMatches.length >= 2) {
              lastPostDate = parseNaverDate(dateMatches[0]);
              addedDate = parseNaverDate(dateMatches[dateMatches.length - 1]);
            } else if (dateMatches.length === 1) {
              addedDate = parseNaverDate(dateMatches[0]);
            }
          }

          // 추가된 지 몇 일 되었는가?
          const daysSinceAdded = addedDate 
            ? Math.max(0, Math.floor((now - addedDate.getTime()) / (1000 * 60 * 60 * 24)))
            : 0;

          // 마지막 글 작성한 지 몇 일 되었는가?
          const daysSinceLastPost = lastPostDate 
            ? Math.max(0, Math.floor((now - lastPostDate.getTime()) / (1000 * 60 * 60 * 24)))
            : 999;

          // 새글소식 OFF 여부
          const isOff = text.includes('OFF');

          // [기능 1] 특정 그룹 절대 보호 판별 (그룹 화이트리스트)
          const protectedGroupKeywords = ['찐이웃', '지인', '가족', 'vip', '보호', '서포터즈', '기자단', '단골'];
          const isProtectedGroup = protectedGroupKeywords.some(kw => groupName.toLowerCase().includes(kw));

          // [기능 5] 탈퇴 / 비공개 블로그 정밀 감지
          const blogLink = r.querySelector('a[href*="blog.naver.com"]');
          const isDeletedOrPrivate = !blogLink || 
            text.includes('비공개') || 
            text.includes('탈퇴') || 
            text.includes('존재하지 않는') || 
            (blogLink && (!blogLink.getAttribute('href') || blogLink.getAttribute('href') === '#' || blogLink.getAttribute('href')?.includes('javascript:')));

          // 뱃지를 부착할 타겟 엘리먼트 (보통 닉네임 링크 또는 해당 td)
          const badgeTarget = blogLink || (tds.length >= 4 ? tds[3] : r);

          validRows.push({
            row: r,
            cb,
            text,
            groupName,
            daysSinceAdded,
            daysSinceLastPost,
            isOff,
            isProtectedGroup,
            isDeletedOrPrivate,
            badgeTarget
          });
        });
      } catch (e) {}
    });
    return validRows;
  }

  // 플로팅 바 생성 및 마운트
  function mountFloatingBar() {
    const targetDoc = getSafeDocument();
    if (targetDoc.getElementById('gifty-floating-bar') || document.getElementById('gifty-floating-bar')) return;

    const bDoc = findBuddyTableDoc();
    if (!bDoc) return;

    const bar = targetDoc.createElement('div');
    bar.id = 'gifty-floating-bar';
    bar.className = 'gifty-float-bar';
    bar.style.cssText = 'position:fixed;bottom:24px;right:24px;z-index:2147483647;background:#0f172a;color:#ffffff;padding:12px 18px;border-radius:20px;box-shadow:0 10px 25px -5px rgba(0,0,0,0.5);display:flex;align-items:center;gap:10px;font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif;border:1px solid rgba(255,255,255,0.15);';
    bar.innerHTML = `
      <div style="font-weight: 800; font-size: 14px; display: flex; align-items: center; gap: 6px;">
        <span style="font-size: 16px;">✨</span> Gifty
      </div>
      <!-- [기능 4] 3단계 정리 강도 조절 선택기 -->
      <select id="gifty-mode-select" style="background:#1e293b;color:#f8fafc;border:1px solid #475569;padding:6px 10px;border-radius:10px;font-size:12px;font-weight:700;cursor:pointer;outline:none;">
        <option value="normal" selected>🟡 보통맛 (30일 보호·60일 미활동)</option>
        <option value="gentle">🟢 순한맛 (60일 보호·90일 유령만)</option>
        <option value="strong">🔴 매운맛 (30일 보호·30일 다이어트)</option>
      </select>
      <button type="button" id="gifty-sync-btn" style="background:#4f46e5;color:#ffffff;border:none;padding:8px 14px;border-radius:10px;font-weight:700;font-size:12px;cursor:pointer;display:flex;align-items:center;gap:5px;box-shadow:0 4px 12px rgba(79,70,229,0.3);transition:all 0.2s;">
        <span>📊 분석실</span>
      </button>
      <button type="button" id="gifty-run-btn" class="gifty-btn-primary" style="background:linear-gradient(135deg,#6366f1 0%,#4338ca 100%);color:#ffffff;border:none;padding:8px 16px;border-radius:10px;font-weight:700;font-size:13px;cursor:pointer;display:flex;align-items:center;gap:6px;box-shadow:0 4px 12px rgba(99,102,241,0.3);">
        <span>⚡ 1초 무소통 정리</span>
      </button>
    `;

    targetDoc.body.appendChild(bar);

    targetDoc.getElementById('gifty-run-btn')?.addEventListener('click', handleRun);
    targetDoc.getElementById('gifty-sync-btn')?.addEventListener('click', handleSyncToGifty);
  }

  // Gifty 분석실 원클릭 연동 핸들러
  async function handleSyncToGifty() {
    const blogId = extractBlogId();
    const validRows = getAllNeighborRows();

    if (validRows.length === 0) {
      alert('이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃 > 이웃목록] 화면인지 확인해 주세요.');
      return;
    }

    const combinedText = validRows.map(r => r.text).join('\n');
    try {
      await navigator.clipboard.writeText(combinedText);
    } catch (e) {}

    try {
      localStorage.setItem('gifty_extension_sync_data', JSON.stringify({
        blogId,
        text: combinedText,
        timestamp: Date.now()
      }));
    } catch (e) {}

    const targetUrl = 'https://gifty.run/neighbor?autoBlogId=' + encodeURIComponent(blogId) + '&sync=extension';
    window.open(targetUrl, '_blank');
    alert(`🎉 ${validRows.length}명의 이웃 데이터를 안전하게 복사했습니다!\n\nGifty 대시보드에서 1초 만에 자동 분석됩니다.`);
  }

  // 실시간 정밀 분석 실행 핸들러
  async function handleRun() {
    const targetDoc = getSafeDocument();
    const btn = targetDoc.getElementById('gifty-run-btn') || document.getElementById('gifty-run-btn');
    if (btn) {
      btn.innerText = '⏳ 실시간 찐이웃 보호 분석 중...';
      btn.style.pointerEvents = 'none';
      btn.style.opacity = '0.7';
    }

    try {
      const validRows = getAllNeighborRows();
      if (validRows.length === 0) {
        alert('이웃 목록을 찾을 수 없습니다. 네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
        return;
      }

      // [기능 4] 3단계 정리 강도 모드 읽기
      const modeSelect = targetDoc.getElementById('gifty-mode-select');
      const mode = modeSelect ? modeSelect.value : 'normal';

      let graceDays = 30; // 신규 이웃 보호 유예기간
      let ghostDays = 60; // 장기 미활동 기준 일수
      let modeName = '보통맛 (권장)';

      if (mode === 'gentle') {
        graceDays = 60;
        ghostDays = 90;
        modeName = '순한맛 (초안전)';
      } else if (mode === 'strong') {
        graceDays = 30;
        ghostDays = 30;
        modeName = '매운맛 (다이어트)';
      }

      // 뱃지 부착 헬퍼 함수
      function setBadge(target, text, type) {
        if (!target) return;
        try {
          target.querySelectorAll('.gifty-reason-badge').forEach(b => b.remove());
          const badge = document.createElement('span');
          badge.className = `gifty-reason-badge gifty-badge-${type}`;
          badge.innerText = text;
          target.appendChild(badge);
        } catch (e) {}
      }

      let protectedCount = 0;
      let newNeighborCount = 0;
      let protectedGroupCount = 0;
      let checkedCount = 0;
      let ghostCount = 0;
      let cutOffCount = 0;
      let deletedAccountCount = 0;

      validRows.forEach((item) => {
        const { row, cb, daysSinceAdded, daysSinceLastPost, isOff, isProtectedGroup, isDeletedOrPrivate, badgeTarget } = item;

        // [우선순위 1] 그룹 화이트리스트 절대 보호: '찐이웃', '지인', '가족' 등 지정 그룹은 무조건 100% 안전 보호!
        if (isProtectedGroup) {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, '🛡️ 찐이웃 그룹 보호', 'safe');
          protectedCount++;
          protectedGroupCount++;
          return;
        }

        // [우선순위 2] 신규 이웃 절대 보호: 추가된 지 graceDays(30~60일) 이내인 이웃은 아직 소통할 기간이 부족하므로 100% 무조건 안심 보호!
        const isNewNeighbor = daysSinceAdded <= graceDays;
        if (isNewNeighbor) {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, `🛡️ 새이웃 (D+${daysSinceAdded}일)`, 'safe');
          protectedCount++;
          newNeighborCount++;
          return;
        }

        // [우선순위 3] 탈퇴 / 비공개 블로그 1순위 타겟팅: 링크 깨짐, 탈퇴 계정은 가장 안전한 정리 대상!
        if (isDeletedOrPrivate) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          setBadge(badgeTarget, '❌ 탈퇴/비공개 의심', 'ghost');
          checkedCount++;
          deletedAccountCount++;
          return;
        }

        // [우선순위 4] 새글소식 차단 이웃: 소식받기 OFF
        const isCutOff = isOff;

        // [우선순위 5] 장기 휴면/무활동 이웃: 최근 글이 ghostDays 이상 전이거나 글이 아예 없음
        const isGhost = daysSinceLastPost >= ghostDays;

        if (isGhost || isCutOff) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          
          if (isCutOff) {
            setBadge(badgeTarget, '❌ 새글소식 OFF', 'warn');
            cutOffCount++;
          } else {
            const postLabel = daysSinceLastPost >= 999 ? '새글 없음' : `새글 ${daysSinceLastPost}일 전`;
            setBadge(badgeTarget, `❌ ${postLabel}`, 'danger');
            ghostCount++;
          }
          checkedCount++;
        } else {
          // 정상 활동 이웃 보호
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, '🛡️ 최근 활동 이웃', 'safe');
          protectedCount++;
        }
      });

      // 결과 안내 팝업
      if (checkedCount === 0 && (newNeighborCount > 0 || protectedGroupCount > 0)) {
        alert(
          `🎉 [Gifty 찐이웃 100% 안심 보호 완료 - ${modeName}]\n\n` +
          `🛡️ 신규 맺은 이웃: ${newNeighborCount}명 안전 보호 (초록색 뱃지)\n` +
          (protectedGroupCount > 0 ? `🛡️ 찐이웃 보호 그룹: ${protectedGroupCount}명 영구 보호\n` : '') +
          `\n💡 [중요 안내]\n` +
          `현재 보고 계신 목록은 소통 유예기간(${graceDays}일) 이내의 소중한 '새이웃'들입니다!\n` +
          `소통 기회가 아직 없었던 새이웃이 억울하게 지워지지 않도록 전원 안전 보호 처리되었습니다.\n\n` +
          `👉 진짜 오래된 무소통/유령 이웃을 정리하시려면:\n` +
          `화면 아래 페이지 번호에서 [맨 끝 페이지(예: 10페이지, 20페이지)]로 이동하신 후 [⚡ 1초 무소통 정리]를 눌러주세요!`
        );
      } else {
        alert(
          `🎉 [Gifty 실시간 정밀 무소통 분석 완료 - ${modeName}]\n\n` +
          `🛡️ 안전 보호 이웃: ${protectedCount}명 (초록색 표시 & 체크 해제)\n` +
          `  - 신규 새이웃(${graceDays}일 이내) 보호: ${newNeighborCount}명\n` +
          (protectedGroupCount > 0 ? `  - 찐이웃 그룹 안심 보호: ${protectedGroupCount}명\n` : '') +
          `\n❌ 무소통 정리 대상: ${checkedCount}명 (분홍색 표시 & 사유 뱃지 부착)\n` +
          (deletedAccountCount > 0 ? `  - 탈퇴/비공개 의심: ${deletedAccountCount}명\n` : '') +
          (ghostCount > 0 ? `  - ${ghostDays}일 이상 글 없는 장기 휴면: ${ghostCount}명\n` : '') +
          (cutOffCount > 0 ? `  - 새글소식 차단(OFF): ${cutOffCount}명\n` : '') +
          `\n※ 각 이웃 옆에 [사유 뱃지]가 부착되었습니다!\n` +
          `확인 후 화면 상단의 [삭제] 버튼을 누르시면 안전하게 한 번에 정리됩니다.`
        );
      }
    } catch (err) {
      alert('분석 중 오류가 발생했습니다: ' + err.message);
    } finally {
      if (btn) {
        btn.innerHTML = '<span>⚡ 1초 무소통 정리</span>';
        btn.style.pointerEvents = 'auto';
        btn.style.opacity = '1';
      }
    }
  }

  // 상시 주기적으로 테이블 감지 후 플로팅 바 마운트
  mountFloatingBar();
  setInterval(mountFloatingBar, 1000);
})();

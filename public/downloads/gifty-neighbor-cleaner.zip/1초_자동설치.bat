@echo off
chcp 65001 > nul
title Gifty 네이버 블로그 이웃 안심 정리기 - 1초 자동 실행기

echo ======================================================
echo    ✨ Gifty 네이버 블로그 이웃 안심 정리기 ✨
echo ======================================================
echo.
echo [1/2] 확장 프로그램 폴더 경로 감지 중...
set "EXT_DIR=%~dp0"
if "%EXT_DIR:~-1%"=="\" set "EXT_DIR=%EXT_DIR:~0,-1%"
echo 감지된 경로: %EXT_DIR%
echo.

echo [2/2] 크롬 브라우저를 찾아 확장 프로그램을 자동 로드합니다...

:: 크롬 실행 경로 탐색
set "BROWSER_EXE="

if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"

:: 크롬이 없으면 네이버 웨일 탐색
if "%BROWSER_EXE%"=="" (
    if exist "%LocalAppData%\Naver\Naver Whale\Application\whale.exe" set "BROWSER_EXE=%LocalAppData%\Naver\Naver Whale\Application\whale.exe"
    if exist "%ProgramFiles%\Naver\Naver Whale\Application\whale.exe" set "BROWSER_EXE=%ProgramFiles%\Naver\Naver Whale\Application\whale.exe"
    if exist "%ProgramFiles(x86)%\Naver\Naver Whale\Application\whale.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Naver\Naver Whale\Application\whale.exe"
)

:: 웨일도 없으면 엣지 탐색
if "%BROWSER_EXE%"=="" (
    if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
    if exist "%ProgramFiles%\Microsoft\Edge\Application\msedge.exe" set "BROWSER_EXE=%ProgramFiles%\Microsoft\Edge\Application\msedge.exe"
)

if "%BROWSER_EXE%"=="" (
    echo [안내] 크롬/웨일/엣지 브라우저를 자동으로 찾지 못했습니다.
    echo 브라우저 주소창에 chrome://extensions 를 열어 이 폴더를 직접 로드해 주세요.
    pause
    exit /b
)

echo 브라우저 연결 확인: %BROWSER_EXE%
echo.
echo ======================================================
echo   🎉 축하합니다! 브라우저가 실행되며 확장 프로그램이
echo      자동으로 장착되어 네이버 화면으로 이동합니다!
echo ======================================================
echo.

start "" "%BROWSER_EXE%" --load-extension="%EXT_DIR%" "https://admin.blog.naver.com/BuddyOrderManage.naver"
timeout /t 2 > nul
exit

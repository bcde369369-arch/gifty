@echo off
chcp 65001 > nul
title Gifty 네이버 블로그 이웃 안심 정리기 - 1초 스마트 자동 설치기

echo ======================================================
echo    ✨ Gifty 네이버 블로그 이웃 안심 정리기 설치기 ✨
echo ======================================================
echo.

:: 1. 확장 프로그램 폴더 경로 감지
set "EXT_DIR=%~dp0"
if "%EXT_DIR:~-1%"=="\" set "EXT_DIR=%EXT_DIR:~0,-1%"

:: 2. 브라우저 실행 파일 탐색
set "BROWSER_EXE="
set "BROWSER_NAME="
set "BROWSER_DISPLAY="

if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%LocalAppData%\Google\Chrome\Application\chrome.exe"
    set "BROWSER_NAME=chrome.exe"
    set "BROWSER_DISPLAY=크롬(Chrome)"
) else if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
    set "BROWSER_NAME=chrome.exe"
    set "BROWSER_DISPLAY=크롬(Chrome)"
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set "BROWSER_EXE=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
    set "BROWSER_NAME=chrome.exe"
    set "BROWSER_DISPLAY=크롬(Chrome)"
)

:: 네이버 웨일 탐색
if "%BROWSER_EXE%"=="" (
    if exist "%LocalAppData%\Naver\Naver Whale\Application\whale.exe" (
        set "BROWSER_EXE=%LocalAppData%\Naver\Naver Whale\Application\whale.exe"
        set "BROWSER_NAME=whale.exe"
        set "BROWSER_DISPLAY=네이버 웨일(Whale)"
    ) else if exist "%ProgramFiles%\Naver\Naver Whale\Application\whale.exe" (
        set "BROWSER_EXE=%ProgramFiles%\Naver\Naver Whale\Application\whale.exe"
        set "BROWSER_NAME=whale.exe"
        set "BROWSER_DISPLAY=네이버 웨일(Whale)"
    )
)

:: 엣지 탐색
if "%BROWSER_EXE%"=="" (
    if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
        set "BROWSER_EXE=%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe"
        set "BROWSER_NAME=msedge.exe"
        set "BROWSER_DISPLAY=마이크로소프트 엣지(Edge)"
    )
)

if "%BROWSER_EXE%"=="" (
    echo [안내] 크롬/웨일 브라우저를 자동으로 찾지 못했습니다.
    echo 브라우저를 켜신 뒤 주소창에 chrome://extensions 를 열어 이 폴더를 직접 끌어다 놓아주세요.
    pause
    exit /b
)

echo 감지된 브라우저: %BROWSER_DISPLAY%
echo.

:: 3. 브라우저 실행 여부 체크 (실행 중이면 자동 장착이 안 되므로 재시작 유도)
tasklist /FI "IMAGENAME eq %BROWSER_NAME%" 2>NUL | find /I /N "%BROWSER_NAME%">NUL
if "%ERRORLEVEL%"=="0" (
    echo ------------------------------------------------------
    echo  ⚠️  현재 %BROWSER_DISPLAY% 창이 켜져 있습니다!
    echo  브라우저 보안상 켜진 상태에서는 새 프로그램이 장착되지 않습니다.
    echo ------------------------------------------------------
    echo.
    echo  [1] 브라우저를 재시작하고 1초 자동 설치 완료하기 (추천 - Enter 누름)
    echo  [2] 직접 확장 프로그램 창(chrome://extensions) 열어서 끌어다 놓기
    echo.
    set "USER_CHOICE="
    set /p "USER_CHOICE=원하시는 번호를 선택하세요 [기본값: 1]: "
    if "%USER_CHOICE%"=="" set USER_CHOICE=1
    if "%USER_CHOICE%"=="1" (
        echo.
        echo %BROWSER_DISPLAY%을 안전하게 재시작한 뒤 자동 장착합니다...
        taskkill /F /IM %BROWSER_NAME% >nul 2>&1
        timeout /t 1 > nul
    ) else (
        echo.
        echo 브라우저 확장프로그램 관리창을 엽니다. 이 폴더를 화면으로 끌어다 놓으세요!
        start "" "%BROWSER_EXE%" "chrome://extensions"
        explorer "%EXT_DIR%"
        echo 완료 후 창을 닫아주세요.
        pause
        exit /b
    )
)

echo.
echo ======================================================
echo   🎉 축하합니다! 브라우저가 실행되며 확장 프로그램이
echo      자동으로 장착되어 네이버 화면으로 이동합니다!
echo ======================================================
echo.

start "" "%BROWSER_EXE%" --load-extension="%EXT_DIR%" "https://section.blog.naver.com/"
timeout /t 2 > nul
exit

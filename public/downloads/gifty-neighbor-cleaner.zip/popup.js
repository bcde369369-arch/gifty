document.getElementById('run-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 네이버 블로그 탭을 찾을 수 없습니다.');
    return;
  }

  // content script 트리거
  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const btn = document.getElementById('gifty-run-btn');
      if (btn) {
        btn.click();
      } else {
        // 직접 실행 fallback
        const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
        const validRows = [];
        rows.forEach(r => {
          const cb = r.querySelector('input[type="checkbox"]');
          if (!cb) return;
          const text = (r.innerText || '').trim();
          if (text.includes('전체선택') || text.includes('이웃그룹') && text.includes('추가일')) return;
          validRows.push({ row: r, cb });
        });

        if (validRows.length > 0) {
          const cutoff = Math.max(1, Math.round(validRows.length * 0.3));
          for (let i = 0; i < validRows.length; i++) {
            const { row, cb } = validRows[i];
            if (i >= validRows.length - cutoff) {
              cb.checked = true;
              cb.dispatchEvent(new Event('change', { bubbles: true }));
              row.style.backgroundColor = '#ffe4e6';
              row.style.outline = '2px solid #f43f5e';
            } else {
              cb.checked = false;
              cb.dispatchEvent(new Event('change', { bubbles: true }));
              row.style.backgroundColor = '#dcfce7';
              row.style.outline = '2px solid #22c55e';
            }
          }
          alert('🎉 [Gifty 이웃 정리 완료]\n\n상단의 [이웃 삭제] 버튼을 누르시면 정리가 완료됩니다.');
        } else {
          alert('이 탭에서 네이버 이웃 관리자 표를 찾지 못했습니다. 네이버 [내가 추가한 이웃] 화면에서 실행해 주세요.');
        }
      }
    }
  });
});

document.getElementById('run-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      function parseNaverDate(dateStr) {
        if (!dateStr) return null;
        const clean = dateStr.replace(/[^0-9.]/g, '').trim();
        const parts = clean.split('.').filter(Boolean).map(Number);
        if (parts.length < 3) return null;
        let year = parts[0];
        if (year < 100) year += 2000;
        const month = parts[1] - 1;
        const day = parts[2];
        const d = new Date(year, month, day);
        return isNaN(d.getTime()) ? null : d;
      }

      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validRows = [];
      const now = Date.now();

      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;

        const dateMatches = text.match(/\b\d{2,4}\.\d{1,2}\.\d{1,2}\b/g) || [];
        let lastPostDate = null;
        let addedDate = null;

        if (dateMatches.length >= 2) {
          lastPostDate = parseNaverDate(dateMatches[0]);
          addedDate = parseNaverDate(dateMatches[1]);
        } else if (dateMatches.length === 1) {
          addedDate = parseNaverDate(dateMatches[0]);
        }

        const daysSinceAdded = addedDate ? Math.floor((now - addedDate.getTime()) / (1000 * 60 * 60 * 24)) : 999;
        const daysSinceLastPost = lastPostDate ? Math.floor((now - lastPostDate.getTime()) / (1000 * 60 * 60 * 24)) : 999;
        const isCommercial = /부동산|대출|분양|중고차|토토|골프샵|보험|렌터|렌트|코인|마케팅대행|체험단|포렉스|투자상담/i.test(text);
        const isOff = text.includes('OFF');

        validRows.push({ row: r, cb, daysSinceAdded, daysSinceLastPost, isCommercial, isOff });
      });

      if (validRows.length === 0) return { count: 0 };

      let protectedCount = 0;
      let newNeighborCount = 0;
      let checkedCount = 0;
      let ghostCount = 0;
      let commercialCount = 0;

      validRows.forEach((item) => {
        const { row, cb, daysSinceAdded, daysSinceLastPost, isCommercial, isOff } = item;
        const isNewNeighbor = daysSinceAdded <= 14;
        const isGhost = daysSinceAdded > 14 && daysSinceLastPost >= 60;
        const isSpam = daysSinceAdded > 7 && isCommercial;
        const isCutOff = daysSinceAdded > 14 && isOff;

        const shouldSelect = !isNewNeighbor && (isGhost || isSpam || isCutOff);

        if (shouldSelect) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          checkedCount++;
          if (isGhost) ghostCount++;
          if (isSpam) commercialCount++;
        } else {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          protectedCount++;
          if (isNewNeighbor) newNeighborCount++;
        }
      });

      return {
        count: validRows.length,
        protectedCount,
        newNeighborCount,
        checkedCount,
        ghostCount,
        commercialCount
      };
    }
  }, (results) => {
    let totalChecked = 0;
    let totalProtected = 0;
    let totalNew = 0;
    let totalGhost = 0;
    let totalCommercial = 0;
    let found = false;

    if (results && results.length > 0) {
      for (const res of results) {
        if (res.result && res.result.count > 0) {
          found = true;
          totalChecked += res.result.checkedCount;
          totalProtected += res.result.protectedCount;
          totalNew += res.result.newNeighborCount;
          totalGhost += res.result.ghostCount;
          totalCommercial += res.result.commercialCount;
        }
      }
    }

    if (found) {
      if (totalChecked === 0 && totalNew > 0) {
        alert(
          `🎉 [Gifty 찐이웃 100% 안심 보호 완료]\n\n` +
          `🛡️ 신규 맺은 이웃: ${totalNew}명 전원 안전 보호 (초록색 표시)\n\n` +
          `💡 [중요 안내]\n` +
          `현재 보고 계신 목록은 모두 최근 2~3일 이내에 추가된 소중한 '새이웃'들입니다!\n` +
          `소통 기회가 아직 없었던 새이웃이 억울하게 지워지지 않도록 전원 안전 보호(초록색) 처리되었습니다.\n\n` +
          `👉 진짜 오래된 무소통/유령 이웃을 정리하시려면:\n` +
          `화면 아래 페이지 번호에서 [맨 끝 페이지(예: 10페이지, 20페이지)]로 이동하신 후 버튼을 눌러주세요!`
        );
      } else {
        alert(
          `🎉 [Gifty 실시간 정밀 무소통 분석 완료]\n\n` +
          `🛡️ 활동·소통 이웃 안전 보호: ${totalProtected}명 (초록색 표시 & 체크 해제)\n` +
          `  - 신규 새이웃 보호: ${totalNew}명\n\n` +
          `❌ 진짜 무소통/유령 이웃 선택: ${totalChecked}명 (분홍색 표시 & 체크 완료)\n` +
          `  - 60일 이상 글 없는 장기 휴면: ${totalGhost}명\n` +
          `  - 상업성 광고/스팸 의심: ${totalCommercial}명\n\n` +
          `화면 상단의 [삭제] 버튼을 누르시면 안전하게 정리가 완료됩니다!`
        );
      }
    } else {
      alert('⚠️ 이 화면에서 네이버 이웃 목록 표를 찾지 못했습니다.\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

document.getElementById('sync-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validText = [];
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
        validText.push(text);
      });
      return validText;
    }
  }, async (results) => {
    let allTexts = [];
    if (results) {
      for (const res of results) {
        if (res.result && Array.isArray(res.result)) {
          allTexts = allTexts.concat(res.result);
        }
      }
    }

    if (allTexts.length > 0) {
      const combined = allTexts.join('\n');
      try {
        await navigator.clipboard.writeText(combined);
      } catch (e) {}
      window.open('https://gifty.run/neighbor?sync=extension', '_blank');
      alert(`🎉 ${allTexts.length}명의 이웃 데이터를 복사했습니다!\n\nGifty 분석실 창으로 이동합니다.`);
    } else {
      alert('⚠️ 이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

document.getElementById('run-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      // 프레임 내 이웃 행 찾기
      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validRows = [];
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
        validRows.push({ row: r, cb });
      });

      if (validRows.length === 0) return { count: 0 };

      const cutoff = Math.max(1, Math.round(validRows.length * 0.3));
      let checkedCount = 0;
      let protectedCount = 0;

      for (let i = 0; i < validRows.length; i++) {
        const { row, cb } = validRows[i];
        if (i >= validRows.length - cutoff) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          checkedCount++;
        } else {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          cb.dispatchEvent(new Event('input', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          protectedCount++;
        }
      }

      return { count: validRows.length, protectedCount, checkedCount };
    }
  }, (results) => {
    let totalChecked = 0;
    let totalProtected = 0;
    let found = false;

    if (results && results.length > 0) {
      for (const res of results) {
        if (res.result && res.result.count > 0) {
          found = true;
          totalChecked += res.result.checkedCount;
          totalProtected += res.result.protectedCount;
        }
      }
    }

    if (found) {
      alert(`🎉 [Gifty 스마트 이웃 정리 완료]\n\n🛡️ 활동·소통 이웃 보호: ${totalProtected}명 (초록색 표시)\n❌ 무소통 이웃 자동 선택: ${totalChecked}명 (분홍색 체크)\n\n화면 상단의 [삭제] 버튼을 누르시면 안전하게 정리가 완료됩니다!`);
    } else {
      alert('⚠️ 이 화면에서 네이버 이웃 목록 표를 찾지 못했습니다.\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

document.getElementById('sync-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validText = [];
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
        validText.push(text);
      });
      return validText;
    }
  }, async (results) => {
    let allTexts = [];
    if (results) {
      for (const res of results) {
        if (res.result && Array.isArray(res.result)) {
          allTexts = allTexts.concat(res.result);
        }
      }
    }

    if (allTexts.length > 0) {
      const combined = allTexts.join('\n');
      try {
        await navigator.clipboard.writeText(combined);
      } catch (e) {}
      window.open('https://gifty.run/neighbor?sync=extension', '_blank');
      alert(`🎉 ${allTexts.length}명의 이웃 데이터를 복사했습니다!\n\nGifty 분석실 창으로 이동합니다.`);
    } else {
      alert('⚠️ 이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

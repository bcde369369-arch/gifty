document.getElementById('run-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 네이버 블로그 탭을 찾을 수 없습니다.');
    return;
  }

  // 메인 프레임에서만 1회 실행하여 모든 iframe을 검색
  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const topDoc = window.top?.document || document;
      const btn = topDoc.getElementById('gifty-run-btn') || document.getElementById('gifty-run-btn');
      if (btn) {
        btn.click();
        return;
      }

      // 모든 프레임 문서 수집
      const docs = [document];
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(f => {
        try {
          const idoc = f.contentDocument || f.contentWindow?.document;
          if (idoc) docs.push(idoc);
        } catch (e) {}
      });

      const validRows = [];
      docs.forEach(d => {
        const rows = d.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
        rows.forEach(r => {
          const cb = r.querySelector('input[type="checkbox"]');
          if (!cb) return;
          const text = (r.innerText || '').trim();
          if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
          validRows.push({ row: r, cb });
        });
      });

      if (validRows.length > 0) {
        const cutoff = Math.max(1, Math.round(validRows.length * 0.3));
        let checkedCount = 0;
        let protectedCount = 0;
        for (let i = 0; i < validRows.length; i++) {
          const { row, cb } = validRows[i];
          if (i >= validRows.length - cutoff) {
            cb.checked = true;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
            row.style.backgroundColor = '#ffe4e6';
            row.style.outline = '2px solid #f43f5e';
            checkedCount++;
          } else {
            cb.checked = false;
            cb.dispatchEvent(new Event('change', { bubbles: true }));
            row.style.backgroundColor = '#dcfce7';
            row.style.outline = '2px solid #22c55e';
            protectedCount++;
          }
        }
        alert(`🎉 [Gifty 이웃 정리 완료]\n\n🛡️ 소통 이웃 보호: ${protectedCount}명\n❌ 무소통 이웃 선택: ${checkedCount}명\n\n상단의 [삭제] 버튼을 누르시면 정리가 완료됩니다.`);
      } else {
        alert('이 탭에서 네이버 이웃 관리자 표를 찾지 못했습니다. 네이버 [내가 추가한 이웃] 화면에서 실행해 주세요.');
      }
    }
  });
});

document.getElementById('sync-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 네이버 블로그 탭을 찾을 수 없습니다.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const topDoc = window.top?.document || document;
      const syncBtn = topDoc.getElementById('gifty-sync-btn') || document.getElementById('gifty-sync-btn');
      if (syncBtn) {
        syncBtn.click();
        return;
      }

      const docs = [document];
      const iframes = document.querySelectorAll('iframe');
      iframes.forEach(f => {
        try {
          const idoc = f.contentDocument || f.contentWindow?.document;
          if (idoc) docs.push(idoc);
        } catch (e) {}
      });

      const validRows = [];
      docs.forEach(d => {
        const rows = d.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
        rows.forEach(r => {
          const cb = r.querySelector('input[type="checkbox"]');
          if (!cb) return;
          const text = (r.innerText || '').trim();
          if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
          validRows.push(text);
        });
      });

      if (validRows.length > 0) {
        const combined = validRows.join('\n');
        navigator.clipboard.writeText(combined);
        window.open('https://gifty.run/neighbor?sync=extension', '_blank');
        alert(`🎉 ${validRows.length}명의 이웃 데이터를 복사했습니다!\n\nGifty 대시보드에서 1초 만에 자동 분석됩니다.`);
      } else {
        alert('네이버 [내가 추가한 이웃] 관리자 화면에서 실행해 주세요.');
      }
    }
  });
});

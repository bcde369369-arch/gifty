document.getElementById('run-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  const mode = document.getElementById('popup-mode-select')?.value || 'normal';

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    args: [mode],
    func: (selectedMode) => {
      function parseNaverDate(dateStr) {
        if (!dateStr) return null;
        const clean = dateStr.replace(/[^0-9.]/g, '').trim();
        const parts = clean.split('.').filter(Boolean).map(Number);
        if (parts.length < 3) return null;
        let year = parts[0];
        if (year < 100) year += 2000;
        const month = parts[1] - 1;
        const day = parts[2];
        const d = new Date(year, month, day);
        return isNaN(d.getTime()) ? null : d;
      }

      function setBadge(target, text, type) {
        if (!target) return;
        try {
          target.querySelectorAll('.gifty-reason-badge').forEach(b => b.remove());
          const badge = document.createElement('span');
          badge.className = `gifty-reason-badge gifty-badge-${type}`;
          badge.innerText = text;
          target.appendChild(badge);
        } catch (e) {}
      }

      let graceDays = 30;
      let ghostDays = 60;
      if (selectedMode === 'gentle') {
        graceDays = 60;
        ghostDays = 90;
      } else if (selectedMode === 'strong') {
        graceDays = 30;
        ghostDays = 30;
      }

      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validRows = [];
      const now = Date.now();

      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;

        const tds = r.querySelectorAll('td');
        let lastPostDate = null;
        let addedDate = null;
        let groupName = '';

        if (tds && tds.length >= 3) {
          groupName = (tds[1]?.innerText || '').trim();
        }

        if (tds && tds.length >= 6) {
          addedDate = parseNaverDate((tds[tds.length - 1]?.innerText || '').trim());
          lastPostDate = parseNaverDate((tds[tds.length - 2]?.innerText || '').trim());
        }

        if (!addedDate) {
          const dateMatches = text.match(/\b\d{2,4}\.\d{1,2}\.\d{1,2}\b/g) || [];
          if (dateMatches.length >= 2) {
            lastPostDate = parseNaverDate(dateMatches[0]);
            addedDate = parseNaverDate(dateMatches[dateMatches.length - 1]);
          } else if (dateMatches.length === 1) {
            addedDate = parseNaverDate(dateMatches[0]);
          }
        }

        const daysSinceAdded = addedDate ? Math.max(0, Math.floor((now - addedDate.getTime()) / 86400000)) : 0;
        const daysSinceLastPost = lastPostDate ? Math.max(0, Math.floor((now - lastPostDate.getTime()) / 86400000)) : 999;
        const isOff = text.includes('OFF');

        // [기능 1] 보호 그룹 화이트리스트
        const isProtectedGroup = ['찐이웃', '지인', '가족', 'vip', '보호', '서포터즈', '기자단', '단골']
          .some(kw => groupName.toLowerCase().includes(kw));

        // [기능 5] 탈퇴/비공개 블로그 감지
        const blogLink = r.querySelector('a[href*="blog.naver.com"]');
        const isDeletedOrPrivate = !blogLink || 
          text.includes('비공개') || 
          text.includes('탈퇴') || 
          text.includes('존재하지 않는') || 
          (blogLink && (!blogLink.getAttribute('href') || blogLink.getAttribute('href') === '#' || blogLink.getAttribute('href')?.includes('javascript:')));

        const badgeTarget = blogLink || (tds.length >= 4 ? tds[3] : r);

        validRows.push({
          row: r,
          cb,
          daysSinceAdded,
          daysSinceLastPost,
          isOff,
          isProtectedGroup,
          isDeletedOrPrivate,
          badgeTarget
        });
      });

      if (validRows.length === 0) return { count: 0 };

      let protectedCount = 0;
      let newNeighborCount = 0;
      let protectedGroupCount = 0;
      let checkedCount = 0;
      let ghostCount = 0;
      let cutOffCount = 0;
      let deletedAccountCount = 0;

      validRows.forEach((item) => {
        const { row, cb, daysSinceAdded, daysSinceLastPost, isOff, isProtectedGroup, isDeletedOrPrivate, badgeTarget } = item;

        // 그룹 화이트리스트 보호
        if (isProtectedGroup) {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, '🛡️ 찐이웃 그룹 보호', 'safe');
          protectedCount++;
          protectedGroupCount++;
          return;
        }

        // 신규 이웃 보호
        if (daysSinceAdded <= graceDays) {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, `🛡️ 새이웃 (D+${daysSinceAdded}일)`, 'safe');
          protectedCount++;
          newNeighborCount++;
          return;
        }

        // 탈퇴/비공개 블로그 1순위 정리
        if (isDeletedOrPrivate) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          setBadge(badgeTarget, '❌ 탈퇴/비공개 의심', 'ghost');
          checkedCount++;
          deletedAccountCount++;
          return;
        }

        const isCutOff = isOff;
        const isGhost = daysSinceLastPost >= ghostDays;

        if (isGhost || isCutOff) {
          cb.checked = true;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#ffe4e6', 'important');
          row.style.setProperty('outline', '2px solid #f43f5e', 'important');
          if (isCutOff) {
            setBadge(badgeTarget, '❌ 새글소식 OFF', 'warn');
            cutOffCount++;
          } else {
            const pText = daysSinceLastPost >= 999 ? '새글 없음' : `새글 ${daysSinceLastPost}일 전`;
            setBadge(badgeTarget, `❌ ${pText}`, 'danger');
            ghostCount++;
          }
          checkedCount++;
        } else {
          cb.checked = false;
          cb.dispatchEvent(new Event('change', { bubbles: true }));
          row.style.setProperty('background-color', '#dcfce7', 'important');
          row.style.setProperty('outline', '2px solid #22c55e', 'important');
          setBadge(badgeTarget, '🛡️ 최근 활동 이웃', 'safe');
          protectedCount++;
        }
      });

      return {
        count: validRows.length,
        protectedCount,
        newNeighborCount,
        protectedGroupCount,
        checkedCount,
        ghostCount,
        cutOffCount,
        deletedAccountCount,
        graceDays,
        ghostDays
      };
    }
  }, (results) => {
    let totalChecked = 0;
    let totalProtected = 0;
    let totalNew = 0;
    let totalGhost = 0;
    let totalGroup = 0;
    let totalDeleted = 0;
    let found = false;

    if (results && results.length > 0) {
      for (const res of results) {
        if (res.result && res.result.count > 0) {
          found = true;
          totalChecked += res.result.checkedCount;
          totalProtected += res.result.protectedCount;
          totalNew += res.result.newNeighborCount;
          totalGhost += res.result.ghostCount;
          totalGroup += (res.result.protectedGroupCount || 0);
          totalDeleted += (res.result.deletedAccountCount || 0);
        }
      }
    }

    if (found) {
      if (totalChecked === 0 && (totalNew > 0 || totalGroup > 0)) {
        alert(
          `🎉 [Gifty 찐이웃 100% 안심 보호 완료]\n\n` +
          `🛡️ 신규 맺은 이웃: ${totalNew}명 안전 보호\n` +
          (totalGroup > 0 ? `🛡️ 찐이웃 보호 그룹: ${totalGroup}명 영구 보호\n` : '') +
          `\n💡 [중요 안내]\n` +
          `현재 보고 계신 목록은 모두 최근 맺은 소중한 '새이웃'들입니다!\n` +
          `소통 기회가 아직 없었던 새이웃이 억울하게 지워지지 않도록 전원 안전 보호(초록색 뱃지) 처리되었습니다.\n\n` +
          `👉 진짜 오래된 무소통/유령 이웃을 정리하시려면:\n` +
          `화면 아래 페이지 번호에서 [맨 끝 페이지]로 이동하신 후 다시 눌러주세요!`
        );
      } else {
        alert(
          `🎉 [Gifty 실시간 정밀 무소통 분석 완료]\n\n` +
          `🛡️ 안전 보호 이웃: ${totalProtected}명 (초록색 표시 & 체크 해제)\n` +
          `  - 신규 새이웃 보호: ${totalNew}명\n` +
          (totalGroup > 0 ? `  - 찐이웃 그룹 안심 보호: ${totalGroup}명\n` : '') +
          `\n❌ 무소통 정리 대상: ${totalChecked}명 (분홍색 표시 & 사유 뱃지 부착)\n` +
          (totalDeleted > 0 ? `  - 탈퇴/비공개 의심: ${totalDeleted}명\n` : '') +
          (totalGhost > 0 ? `  - 장기 휴면 이웃: ${totalGhost}명\n` : '') +
          `\n※ 각 이웃 옆에 [사유 뱃지]가 부착되었습니다!\n` +
          `확인 후 화면 상단의 [삭제] 버튼을 누르시면 안전하게 한 번에 정리됩니다.`
        );
      }
    } else {
      alert('⚠️ 이웃 목록을 찾을 수 없습니다. 네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});
        alert(
          `🎉 [Gifty 찐이웃 100% 안심 보호 완료]\n\n` +
          `🛡️ 신규 맺은 이웃: ${totalNew}명 전원 안전 보호 (초록색 표시)\n\n` +
          `💡 [중요 안내]\n` +
          `현재 보고 계신 목록은 모두 최근 2~3일 이내에 추가된 소중한 '새이웃'들입니다!\n` +
          `소통 기회가 아직 없었던 새이웃이 억울하게 지워지지 않도록 전원 안전 보호(초록색) 처리되었습니다.\n\n` +
          `👉 진짜 오래된 무소통/유령 이웃을 정리하시려면:\n` +
          `화면 아래 페이지 번호에서 [맨 끝 페이지(예: 10페이지, 20페이지)]로 이동하신 후 버튼을 눌러주세요!`
        );
      } else {
        alert(
          `🎉 [Gifty 실시간 정밀 무소통 분석 완료]\n\n` +
          `🛡️ 활동·소통 이웃 안전 보호: ${totalProtected}명 (초록색 표시 & 체크 해제)\n` +
          `  - 신규 새이웃 보호: ${totalNew}명\n\n` +
          `❌ 장기 휴면/무소통 이웃 선택: ${totalChecked}명 (분홍색 표시 & 체크 완료)\n` +
          `  - 60일 이상 글 없는 장기 휴면: ${totalGhost}명\n\n` +
          `화면 상단의 [삭제] 버튼을 누르시면 안전하게 정리가 완료됩니다!`
        );
      }
    } else {
      alert('⚠️ 이 화면에서 네이버 이웃 목록 표를 찾지 못했습니다.\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

document.getElementById('sync-btn')?.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) {
    alert('활성화된 탭을 찾을 수 없습니다.');
    return;
  }

  if (!tab.url || (!tab.url.includes('blog.naver.com') && !tab.url.includes('admin.blog.naver.com'))) {
    alert('⚠️ 네이버 블로그 화면이 아닙니다!\n\n네이버 [내 블로그 > 관리 > 내가 추가한 이웃] 화면으로 이동하신 후 눌러주세요.');
    return;
  }

  chrome.scripting.executeScript({
    target: { tabId: tab.id, allFrames: true },
    func: () => {
      const rows = document.querySelectorAll('table tr, tbody tr, .buddy_list li, ul li');
      const validText = [];
      rows.forEach(r => {
        const cb = r.querySelector('input[type="checkbox"]');
        if (!cb) return;
        const text = (r.innerText || '').trim();
        if (text.includes('전체선택') || (text.includes('이웃그룹') && text.includes('추가일'))) return;
        validText.push(text);
      });
      return validText;
    }
  }, async (results) => {
    let allTexts = [];
    if (results) {
      for (const res of results) {
        if (res.result && Array.isArray(res.result)) {
          allTexts = allTexts.concat(res.result);
        }
      }
    }

    if (allTexts.length > 0) {
      const combined = allTexts.join('\n');
      try {
        await navigator.clipboard.writeText(combined);
      } catch (e) {}
      window.open('https://gifty.run/neighbor?sync=extension', '_blank');
      alert(`🎉 ${allTexts.length}명의 이웃 데이터를 복사했습니다!\n\nGifty 분석실 창으로 이동합니다.`);
    } else {
      alert('⚠️ 이웃 목록을 찾을 수 없습니다. 네이버 [내가 추가한 이웃] 화면인지 확인해 주세요.');
    }
  });
});

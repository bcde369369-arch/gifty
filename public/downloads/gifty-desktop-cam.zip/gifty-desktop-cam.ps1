﻿# Gifty Cam - 실제 모니터 위 투명 자유 프레임 캡처기
Add-Type -AssemblyName PresentationFramework
Add-Type -AssemblyName PresentationCore
Add-Type -AssemblyName WindowsBase
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Windows.Forms

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Gifty Desktop Frame"
        WindowStyle="None"
        AllowsTransparency="True"
        Background="Transparent"
        Topmost="True"
        ResizeMode="CanResizeWithGrip"
        Width="806" Height="642" Left="200" Top="150"
        MinWidth="300" MinHeight="250">
    <Border BorderBrush="#F97316" BorderThickness="4" CornerRadius="8" Background="Transparent">
        <Grid>
            <Grid.RowDefinitions>
                <RowDefinition Height="38"/>
                <RowDefinition Height="*"/>
            </Grid.RowDefinitions>

            <!-- 상단 이동 바 & 조작 패널 -->
            <Border Grid.Row="0" Background="#1E293B" CornerRadius="4,4,0,0" x:Name="HeaderBar" Cursor="SizeAll">
                <Grid Margin="10,0,10,0">
                    <Grid.ColumnDefinitions>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="Auto"/>
                        <ColumnDefinition Width="*"/>
                        <ColumnDefinition Width="Auto"/>
                    </Grid.ColumnDefinitions>

                    <!-- 타이틀 & 실시간 치수 -->
                    <StackPanel Grid.Column="0" Orientation="Horizontal" VerticalAlignment="Center">
                        <TextBlock Text="🎥 Gifty Cam" Foreground="#F97316" FontWeight="Bold" FontSize="12" VerticalAlignment="Center"/>
                        <Border Background="#F97316" CornerRadius="4" Margin="8,0,0,0" Padding="6,2">
                            <TextBlock x:Name="TxtSize" Text="800 × 600" Foreground="White" FontWeight="Black" FontSize="11"/>
                        </Border>
                    </StackPanel>

                    <!-- 규격 프리셋 버튼들 -->
                    <StackPanel Grid.Column="1" Orientation="Horizontal" Margin="12,0,0,0" VerticalAlignment="Center">
                        <Button x:Name="BtnBlog" Content="블로그(4:3)" Background="#334155" Foreground="White" BorderThickness="0" Padding="8,3" Margin="2,0" FontWeight="Bold" FontSize="11" Cursor="Hand"/>
                        <Button x:Name="BtnWide" Content="와이드(16:9)" Background="#334155" Foreground="White" BorderThickness="0" Padding="8,3" Margin="2,0" FontWeight="Bold" FontSize="11" Cursor="Hand"/>
                        <Button x:Name="BtnSquare" Content="1:1" Background="#334155" Foreground="White" BorderThickness="0" Padding="8,3" Margin="2,0" FontWeight="Bold" FontSize="11" Cursor="Hand"/>
                        <Button x:Name="BtnShorts" Content="쇼츠(9:16)" Background="#334155" Foreground="White" BorderThickness="0" Padding="8,3" Margin="2,0" FontWeight="Bold" FontSize="11" Cursor="Hand"/>
                    </StackPanel>

                    <!-- 오른쪽 캡처 & 닫기 버튼 -->
                    <StackPanel Grid.Column="3" Orientation="Horizontal" VerticalAlignment="Center">
                        <Button x:Name="BtnCapture" Content="📸 이 영역 캡처" Background="#EA580C" Foreground="White" BorderThickness="0" Padding="12,4" FontWeight="Black" FontSize="11" Cursor="Hand" Margin="0,0,6,0"/>
                        <Button x:Name="BtnClose" Content="✕" Background="#475569" Foreground="White" BorderThickness="0" Padding="8,4" FontWeight="Black" FontSize="11" Cursor="Hand"/>
                    </StackPanel>
                </Grid>
            </Border>

            <!-- 중앙 투명 뷰파인더 영역 (아래 깔린 창 클릭 가능) -->
            <Grid Grid.Row="1" x:Name="ViewportArea" Background="Transparent" IsHitTestVisible="False">
            </Grid>
        </Grid>
    </Border>
</Window>
"@

$reader = (New-Object System.Xml.XmlNodeReader $xaml)
$window = [System.Windows.Markup.XamlReader]::Load($reader)

# 컨트롤 연결
$headerBar = $window.FindName("HeaderBar")
$txtSize = $window.FindName("TxtSize")
$btnBlog = $window.FindName("BtnBlog")
$btnWide = $window.FindName("BtnWide")
$btnSquare = $window.FindName("BtnSquare")
$btnShorts = $window.FindName("BtnShorts")
$btnCapture = $window.FindName("BtnCapture")
$btnClose = $window.FindName("BtnClose")

# 창 크기 변경 시 치수 실시간 표시
$updateSize = {
    $innerW = [int]($window.Width - 8)
    $innerH = [int]($window.Height - 38 - 8)
    $txtSize.Text = "$innerW × $innerH px"
}

$window.Add_SizeChanged({ & $updateSize })
$window.Add_Loaded({ & $updateSize })

# 상단 바 잡고 창 이동
$headerBar.Add_MouseLeftButtonDown({
    $window.DragMove()
})

# 프리셋 버튼 클릭 이벤트
$btnBlog.Add_Click({
    $window.Width = 808
    $window.Height = 646
    & $updateSize
})

$btnWide.Add_Click({
    $window.Width = 968
    $window.Height = 582
    & $updateSize
})

$btnSquare.Add_Click({
    $window.Width = 608
    $window.Height = 646
    & $updateSize
})

$btnShorts.Add_Click({
    $window.Width = 458
    $window.Height = 846
    & $updateSize
})

# 닫기 버튼
$btnClose.Add_Click({
    $window.Close()
})

# 📸 영역 스크린샷 캡처
$btnCapture.Add_Click({
    try {
        # DPI 배율 감안
        $source = [System.Windows.PresentationSource]::FromVisual($window)
        $dpiX = if ($source) { $source.CompositionTarget.TransformToDevice.M11 } else { 1.0 }
        $dpiY = if ($source) { $source.CompositionTarget.TransformToDevice.M22 } else { 1.0 }

        $left = [int](($window.Left + 4) * $dpiX)
        $top = [int](($window.Top + 38 + 4) * $dpiY)
        $width = [int](($window.Width - 8) * $dpiX)
        $height = [int](($window.Height - 38 - 8) * $dpiY)

        # 캡처를 위해 창 잠시 숨김
        $window.Visibility = [System.Windows.Visibility]::Hidden
        Start-Sleep -Milliseconds 120

        $bitmap = New-Object System.Drawing.Bitmap($width, $height)
        $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
        $graphics.CopyFromScreen($left, $top, 0, 0, (New-Object System.Drawing.Size($width, $height)))

        # 클립보드에 즉시 복사 (Ctrl+V 로 바로 붙여넣기 가능!)
        [System.Windows.Forms.Clipboard]::SetImage($bitmap)

        # 바탕화면에 파일 저장
        $saveDir = [System.Environment]::GetFolderPath([System.Environment+SpecialFolder]::DesktopDirectory)
        $filename = "gifty_capture_" + (Get-Date -Format "yyyyMMdd_HHmmss") + ".png"
        $filePath = Join-Path $saveDir $filename
        $bitmap.Save($filePath, [System.Drawing.Imaging.ImageFormat]::Png)

        $graphics.Dispose()
        $bitmap.Dispose()

        # 창 복구
        $window.Visibility = [System.Windows.Visibility]::Visible

        # 알림 메시지
        [System.Windows.Forms.MessageBox]::Show("캡처 완료! 클립보드에 복사되었으며 바탕화면에도 저장되었습니다.`n`n파일: $filePath`n`n클립보드에 들어있으므로 이미지 스튜디오나 블로그에 바로 Ctrl + V 하시면 됩니다!", "Gifty Cam 캡처 완료", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information)
    } catch {
        $window.Visibility = [System.Windows.Visibility]::Visible
        [System.Windows.Forms.MessageBox]::Show("캡처 중 오류가 발생했습니다: $_", "오류", [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error)
    }
})

$window.ShowDialog() | Out-Null

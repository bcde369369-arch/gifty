@echo off
cd /d "%~dp0"
title Gifty Cam
echo ========================================================
echo   Gifty Cam - Real Monitor Transparent Frame
echo ========================================================
echo [Notice] A transparent orange frame will appear on your screen.
echo Drag and resize the frame over any app (YouTube, Browser, etc.)
echo.
powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -File "gifty-desktop-cam.ps1"
if %ERRORLEVEL% neq 0 (
    echo.
    echo [Error occurred. Press any key to exit.]
    pause
)
